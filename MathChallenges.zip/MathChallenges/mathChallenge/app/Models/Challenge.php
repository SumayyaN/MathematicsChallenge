<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Challenge extends Model
{
    use HasFactory;
protected $fillable = [
    'challengeNo',
    'challenge_name',
    'open_date',
    'close_date',
    'duration',
    'number_of_questions',
    'questions_file_path',
    'answers_file_path',
];

}


