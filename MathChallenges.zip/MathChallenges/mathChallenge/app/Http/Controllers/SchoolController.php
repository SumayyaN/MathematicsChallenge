<?php

namespace App\Http\Controllers;
use App\Models\School;
use Illuminate\Http\Request;

class SchoolController extends Controller
{
    public function create()
    {
        return view('schools.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'reg_no' => 'required',
            'name' => 'required',
            'district' => 'required',
            'school_representative_name' => 'required',
            'school_representative_email' => 'required|email|unique:schools',
        ]);

        School::create($request->all());

        return redirect()->route('schools.create')
            ->with('success', 'School details have been successfully added.');
    }
}

