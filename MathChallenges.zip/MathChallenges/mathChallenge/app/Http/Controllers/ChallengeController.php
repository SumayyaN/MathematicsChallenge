<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Challenge;

class ChallengeController extends Controller
{
    public function create()
    {
        return view('challenges.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'challengeNo' => 'required|unique:challenges',
            'challenge_name' => 'required|string|max:25',
            'open_date' => 'required|date',
            'close_date' => 'required|date',
            'duration' => 'required|integer|min:1|max:120', // Validate duration
            'number_of_questions' => 'required|integer|min:1|max:15', // Validate number of questions
            'questions_file' => 'required',
            'answers_file' => 'required',
            
        ]);

        $questionsPath = $request->file('questions_file')->store('uploads', 'public');
        $answersPath = $request->file('answers_file')->store('uploads', 'public');

        Challenge::create([
            'challengeNo' => $request->challengeNo,
            'challenge_name' => $request->challenge_name,
            'open_date' => $request->open_date,
            'close_date' => $request->close_date,
            'duration' => $request->duration,
            'number_of_questions' => $request->number_of_questions,
            'questions_file' => $questionsPath,
            'answers_file' => $answersPath,
        ]);

        return redirect()->route('challenges.create')->with('success', 'Challenge created successfully.');
    }
}






