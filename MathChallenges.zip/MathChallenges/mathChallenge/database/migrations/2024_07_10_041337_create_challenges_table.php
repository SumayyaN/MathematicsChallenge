<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('challenges', function (Blueprint $table) {
            $table->string('challengeNo')->unique();
            $table->date('open_date');
            $table->date('close_date');
            $table->unsignedInteger('duration')->nullable(); // Change to unsigned integer
            $table->unsignedInteger('number_of_questions')->nullable(); // Change to unsigned integer
            $table->string('questions_file')->nullable();
            $table->string('answers_file')->nullable();
            $table->timestamps();
        });
    }
    

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('challenges');
    }
};

