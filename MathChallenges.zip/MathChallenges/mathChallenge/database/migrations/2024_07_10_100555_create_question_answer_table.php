<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Question_Answer', function (Blueprint $table) {
            $table->id('questionID'); // Primary key
            $table->text('Question');
            $table->text('Answer');
            $table->integer('Mark');
            $table->timestamps(); // Created_at and updated_at timestamps
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('question_answer');
    }
};



