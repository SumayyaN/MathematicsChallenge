<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('AcceptedApplicant', function (Blueprint $table) {
            $table->string('participantUserName', 15);
            $table->string('firstName', 15);
            $table->string('lastName', 15);
            $table->string('email', 25)->primary();
            $table->date('DOB');
            $table->string('schoolRegNumber', 15)->index(); 
            $table->string('image'); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('acceptedapplicant');
    }
};
