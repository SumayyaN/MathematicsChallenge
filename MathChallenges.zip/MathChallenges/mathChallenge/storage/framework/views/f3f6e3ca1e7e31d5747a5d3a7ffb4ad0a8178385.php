<!-- resources/views/challenges/create.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Challenge</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f9f4fd;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #ffffff;
            color: black;
            text-align: center;
            border-bottom: none;
            border-radius: 10px 10px 0 0;
        }
        .card-body {
            padding: 20px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #a358e8;
            border: none;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #8a2be2;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h3>Set Challenge</h3>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('challenges.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="challengeNo">Challenge No:</label>
                        <input type="text" class="form-control" id="challengeNo" name="challengeNo" required>
                    </div>
                    <div class="form-group">
                        <label for="challenge_name">Challenge Name (1-25 characters):</label>
                        <input type="text" class="form-control" id="challenge_name" name="challenge_name" maxlength="25" required>
                    </div>
                    <div class="form-group">
                        <label for="open_date">Open Date:</label>
                        <input type="date" class="form-control" id="open_date" name="open_date" required>
                    </div>
                    <div class="form-group">
                        <label for="close_date">Close Date:</label>
                        <input type="date" class="form-control" id="close_date" name="close_date" required>
                    </div>
                    <div class="form-group">
                        <label for="duration">Duration (in minutes, 1-120):</label>
                        <input type="number" class="form-control" id="duration" name="duration" min="1" max="120" required>
                    </div>
                    <div class="form-group">
                        <label for="number_of_questions">Number of Questions (1-15):</label>
                        <input type="number" class="form-control" id="number_of_questions" name="number_of_questions" min="1" max="15" required>
                    </div>
                    <div class="form-group">
                        <label for="questions_file">Upload Questions (Excel):</label>
                        <input type="file" class="form-control" id="questions_file" name="questions_file" accept=".xlsx" required>
                    </div>
                    <div class="form-group">
                        <label for="answers_file">Upload Answers (Excel):</label>
                        <input type="file" class="form-control" id="answers_file" name="answers_file" accept=".xlsx" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Create Challenge</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\aryam\Desktop\MathChallenges\mathChallenge\resources\views/challenges/create.blade.php ENDPATH**/ ?>