<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register School</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f9f4fd;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #ffffff;
            color: black;
            text-align: center;
            border-radius: 15px 15px 0 0;
        }
        .card-body {
            padding: 20px;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #a358e8;
            border: none;
            border-radius: 5px;
        }
        .btn-primary:hover {
            background-color: #8a2be2;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Register School</h2>
            </div>
            <div class="card-body">
                @if ($message = Session::get('success'))
                    <div class="alert alert-success">
                        <p>{{ $message }}</p>
                    </div>
                @endif

                <form action="{{ route('schools.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="reg_no">Registration Number</label>
                        <input type="text" class="form-control" id="reg_no" name="reg_no" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="district">District</label>
                        <input type="text" class="form-control" id="district" name="district" required>
                    </div>
                    <div class="form-group">
                        <label for="school_representative_name">Representative Name</label>
                        <input type="text" class="form-control" id="school_representative_name" name="school_representative_name" required>
                    </div>
                    <div class="form-group">
                        <label for="school_representative_email">Representative Email</label>
                        <input type="email" class="form-control" id="school_representative_email" name="school_representative_email" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Submit</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
