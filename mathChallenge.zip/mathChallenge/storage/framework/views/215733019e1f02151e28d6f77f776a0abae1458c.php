

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header text-center" style="
            background-color: #f39c12;
            color: white;
            padding: 20px;
            border-radius: 5px 5px 0 0;
        ">
            <h2 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                Add New School
            </h2>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('schools.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="regNo">Registration Number:</label>
                    <input type="text" class="form-control" id="regNo" name="regNo" placeholder="Enter Registration Number" value="<?php echo e(old('regNo')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter School Name" value="<?php echo e(old('name')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="district">District:</label>
                    <input type="text" class="form-control" id="district" name="district" placeholder="Enter District" value="<?php echo e(old('district')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="representative_name">Representative Name:</label>
                    <input type="text" class="form-control" id="representative_name" name="school_representative_name" placeholder="Enter Representative Name" value="<?php echo e(old('school_representative_name')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="representative_email">Representative Email:</label>
                    <input type="email" class="form-control" id="representative_email" name="school_representative_email" placeholder="Enter Representative Email" value="<?php echo e(old('school_representative_email')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="representative_password">Representative Password:</label>
                    <input type="password" class="form-control" id="representative_password" name="representativePassword" placeholder="Enter Password" required>
                    <small class="form-text text-muted">
                        Password must be at least 8 characters long.
                    </small>
                </div>
                <button type="submit" class="btn btn-primary w-100">Submit</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'table', 'title' => 'School Registration', 'navName' => 'School Registration', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/schools/create.blade.php ENDPATH**/ ?>