<!-- resources/views/challenge_ranking.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Challenge Ranking</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <h1>Challenge Ranking</h1>
    <table>
        <thead>
            <tr>
                <th>Challenge No</th>
                <th>Challenge Name</th>
                <th>School Reg No</th>
                <th>School Name</th>
                <th>Position</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rankings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ranking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ranking->challengeNo); ?></td>
                    <td><?php echo e($ranking->challengeName); ?></td>
                    <td><?php echo e($ranking->regNo); ?></td>
                    <td><?php echo e($ranking->schoolName); ?></td>
                    <td><?php echo e($ranking->position); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/challenge_ranking.blade.php ENDPATH**/ ?>