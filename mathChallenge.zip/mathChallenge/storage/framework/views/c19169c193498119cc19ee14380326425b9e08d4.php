<!-- resources/views/challenges/create.blade.php -->


<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Challenge</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="container">
        <h2>Create Challenge</h2>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('challenges.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="challengeNo">Challenge No:</label>
                <input type="number" class="form-control" id="challengeNo" name="challengeNo" required>
            </div>
            <div class="form-group">
                <label for="challengeName">Challenge Name:</label>
                <input type="text" class="form-control" id="challengeName" name="challengeName" required>
            </div>
            <div class="form-group">
                <label for="openDate">Open Date:</label>
                <input type="date" class="form-control" id="openDate" name="openDate" required>
            </div>
            <div class="form-group">
                <label for="closeDate">Close Date:</label>
                <input type="date" class="form-control" id="closeDate" name="closeDate" required>
            </div>
            <div class="form-group">
                <label for="duration">Duration (in minutes):</label>
                <input type="number" class="form-control" id="duration" name="duration" required>
            </div>
            <div class="form-group">
                <label for="numberOfQuestions">Number of Questions:</label>
                <input type="number" class="form-control" id="numberOfQuestions" name="numberOfQuestions" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'table', 'title' => 'Light Bootstrap Dashboard Laravel by Creative Tim & UPDIVISION', 'navName' => 'Table List', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/challenges/create.blade.php ENDPATH**/ ?>