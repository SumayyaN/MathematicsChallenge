<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card">
        <div class="card-header text-center" style="
            background-color: #f39c12;
            color: white;
            padding: 20px;
            border-radius: 5px 5px 0 0;
        ">
            <h2 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                Welcome, Dear Administrator!
            </h2>
        </div>
        <div class="card-body">
            <p style="font-family: 'Arial, sans-serif'; color: #2c3e50; font-size: 18px; line-height: 1.6;">
                Welcome. The left sidebar provides access to various tasks for managing the mathematics challenge. Below is a summary of each tab:
            </p>
            <ul class="list-group list-group-flush">
                <li class="list-group-item" style="font-family: 'Arial, sans-serif'; font-size: 18px;">Register School: Upload details of eligible schools for the math challenge.</li>
                <li class="list-group-item" style="font-family: 'Arial, sans-serif'; font-size: 18px;">Set Challenge: Establish parameters for a specific challenge.</li>
                <li class="list-group-item" style="font-family: 'Arial, sans-serif'; font-size: 18px;">Upload Files: Store challenge Questions and Answers in the database.</li>
                <li class="list-group-item" style="font-family: 'Arial, sans-serif'; font-size: 18px;">
                    Analytics:
                    <ul class="list-unstyled pl-3">
                        <li>Most Correctly Answered Questions: Questions answered correctly.</li>
                        <li>School Ranking: Ranking of schools for a given challenge.</li>
                        <li>Performance Over Time: Schools' and participants' performance over time.</li>
                        <li>Question Repetition Rate: Percentage of repeated questions for a participant.</li>
                        <li>Best & Worst Performing Schools: List of worst and best performing schools.</li>
                        <li>Incomplete Challenges: List of participants with incomplete challenges.</li>
                    </ul>
                </li>
            </ul>
            <p style="font-family: 'Arial, sans-serif'; color: #2c3e50; font-size: 18px; line-height: 1.6; margin-top: 20px;">
                Thank you for your dedication and hard work. Let's make this challenge a success!
            </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            // Initialize any JavaScript functions here
            demo.initDashboardPageCharts();

            // demo.showNotification(); // Uncomment if needed
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'dashboard', 'title' => 'Mathematics Challenge', 'navName' => 'Dashboard', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/dashboard.blade.php ENDPATH**/ ?>