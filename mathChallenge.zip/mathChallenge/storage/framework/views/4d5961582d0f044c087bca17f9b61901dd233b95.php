

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center" style="
                    background-color: #f39c12;
                    color: white;
                    padding: 20px;
                    border-radius: 5px 5px 0 0;
                ">
                    <h4 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                        Import Questions and Answers
                    </h4>
                </div>
                <div class="card-body">
                    <form id="questionForm" enctype="multipart/form-data" style="padding: 20px;">
                        <?php echo csrf_field(); ?>
                        <div class="input-group mb-3">
                            <input type="file" name="questionFile" class="form-control" />
                            <button type="button" id="submitQuestionForm" class="btn btn-primary" style="
                                width: 150px;
                                border-radius: 5px;
                                background-color: #007bff;
                                color: white;
                                margin-left: 10px;
                            ">Import Questions</button>
                        </div>
                    </form>
                    <form id="answerForm" enctype="multipart/form-data" style="padding: 20px;">
                        <?php echo csrf_field(); ?>
                        <div class="input-group mb-3">
                            <input type="file" name="answerFile" class="form-control" />
                            <button type="button" id="submitAnswerForm" class="btn btn-primary" style="
                                width: 150px;
                                border-radius: 5px;
                                background-color: #007bff;
                                color: white;
                                margin-left: 10px;
                            ">Import Answers</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('#submitQuestionForm').click(function() {
            var formData = new FormData($('#questionForm')[0]);
            $.ajax({
                url: '<?php echo e(url('question/import')); ?>',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    alert(response.status);
                    $('#questionForm')[0].reset();
                },
                error: function(xhr) {
                    var errorMessage = xhr.responseJSON ? xhr.responseJSON.error : 'Error uploading questions';
                    alert(errorMessage);
                }
            });
        });

        $('#submitAnswerForm').click(function() {
            var formData = new FormData($('#answerForm')[0]);
            $.ajax({
                url: '<?php echo e(url('answer/import')); ?>',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    alert(response.status);
                    $('#answerForm')[0].reset();
                },
                error: function(xhr) {
                    var errorMessage = xhr.responseJSON ? xhr.responseJSON.error : 'Error uploading answers';
                    alert(errorMessage);
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'table', 'title' => 'File Upload', 'navName' => 'Upload Files', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/question/index.blade.php ENDPATH**/ ?>