

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center" style="
                    background-color: #f39c12;
                    color: white;
                    padding: 20px;
                    border-radius: 5px 5px 0 0;
                ">
                    <h4 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                        School Rankings
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Challenge No</th>
                                <th>Challenge Name</th>
                                <th>School Registration No</th>
                                <th>School Name</th>
                                <th>Position</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $challengeRankings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ranking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ranking->challengeNo); ?></td>
                                    <td><?php echo e($ranking->challengeName); ?></td>
                                    <td><?php echo e($ranking->regNo); ?></td>
                                    <td><?php echo e($ranking->schoolName); ?></td>
                                    <td><?php echo e($ranking->position); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'School Rankings', 'title' => 'Ranking', 'navName' => 'Schools Ranking', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/challenge/rankings.blade.php ENDPATH**/ ?>