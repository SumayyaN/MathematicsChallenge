

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card">
        <div class="card-header text-center" style="
            background-color: #f39c12;
            color: white;
            padding: 20px;
            border-radius: 5px 5px 0 0;
        ">
            <h4 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                Question Repetition Report
            </h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>User Name</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Challenge No</th>
                        <th>Challenge Name</th>
                        <th>Question Repetition Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($record->userName); ?></td>
                            <td><?php echo e($record->firstName); ?></td>
                            <td><?php echo e($record->lastName); ?></td>
                            <td><?php echo e($record->challengeNo); ?></td>
                            <td><?php echo e($record->challengeName); ?></td>
                            <td><?php echo e(number_format($record->questionRepetitionPercentage, 1)); ?>%</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Question Repetition Rate', 'title' => 'Question Repetition Rate', 'navName' => 'Question Repetition Rate', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/question-repetition/index.blade.php ENDPATH**/ ?>