<!--  -->
<?php $__env->startSection('content'); ?>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Questions</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body> -->
    <div class="container">
        <h1>Top 5 most correctly answered Questions</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Challenge Number</th>
                    <th>Question Number</th>
                    <th>Question</th>
                    <th>Correct Count</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $topQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($question->challengeNo); ?></td>
                        <td><?php echo e($question->questionNo); ?></td>
                        <td><?php echo e($question->question); ?></td>
                        <td><?php echo e($question->correct_count); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'table', 'title' => 'School Registration', 'navName' => 'School Registration', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/top-questions.blade.php ENDPATH**/ ?>