

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <!-- Title Section -->
    <div class="text-center mb-4">
        <h1 style="
            font-family: 'Arial, sans-serif';
            font-weight: bold;
            color: ##f39c12;
            background: linear-gradient(to right, #f39c12, #e74c3c);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 36px;
        ">Combined School Performance Report</h1>
    </div>

    <!-- Worst Performing Schools Section -->
    <div class="mb-5">
        <h2 style="
            font-family: 'Arial, sans-serif';
            color: #2c3e50;
            font-size: 24px;
            font-weight: bold;
            border-bottom: 2px solid #e74c3c;
            padding-bottom: 10px;
        ">Worst Performing Schools by Challenge</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Challenge No</th>
                    <th>Challenge Name</th>
                    <th>School Reg No</th>
                    <th>School Name</th>
                    <th>School Performance</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $worstPerformingSchools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($school->challengeNo); ?></td>
                        <td><?php echo e($school->challengeName); ?></td>
                        <td><?php echo e($school->regNo); ?></td>
                        <td><?php echo e($school->schoolName); ?></td>
                        <td><?php echo e(number_format($school->schoolPerformance, 1)); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Best Performing Schools Section -->
    <div>
        <h2 style="
            font-family: 'Arial, sans-serif';
            color: #2c3e50;
            font-size: 24px;
            font-weight: bold;
            border-bottom: 2px solid #2ecc71;
            padding-bottom: 10px;
        ">Best Performing Schools Across All Challenges</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>School Reg No</th>
                    <th>School Name</th>
                    <th>Overall School Performance</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bestPerformingSchools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($school->regNo); ?></td>
                        <td><?php echo e($school->schoolName); ?></td>
                        <td><?php echo e(number_format($school->schoolPerformance, 1)); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'School Performance', 'title' => 'School Performance', 'navName' => 'Best and Worst Performing Schools', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/combined-performance/index.blade.php ENDPATH**/ ?>