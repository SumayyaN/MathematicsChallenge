

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="text-center mb-4">
        <h1 style="
            font-family: 'Arial, sans-serif';
            font-weight: bold;
            background-color: white;
            color: #f39c12;
            padding: 15px;
            border-radius: 5px;
            display: inline-block;
        ">Most Correctly Answered Questions</h1>
    </div>
    <table class="table table-striped" style="border-collapse: collapse;">
        <thead style="background-color: white; color: black;">
            <tr>
                <th style="border-right: 1px solid #ddd;">Challenge Number</th>
                <th style="border-right: 1px solid #ddd;">Question Number</th>
                <th style="border-right: 1px solid #ddd;">Question</th>
                <th>Correct Count</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $topQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border-right: 1px solid #ddd;"><?php echo e($question->challengeNo); ?></td>
                    <td style="border-right: 1px solid #ddd;"><?php echo e($question->questionNo); ?></td>
                    <td style="border-right: 1px solid #ddd;"><?php echo e($question->question); ?></td>
                    <td><?php echo e($question->correct_count); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Top Questions', 'title' => 'Top Questions', 'navName' => 'Top Questions', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/TopQuestions\top-questions.blade.php ENDPATH**/ ?>