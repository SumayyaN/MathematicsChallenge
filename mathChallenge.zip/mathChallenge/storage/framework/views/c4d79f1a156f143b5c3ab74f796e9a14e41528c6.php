

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="text-center mb-4">
        <h1 style="
            font-family: 'Arial, sans-serif';
            color: white;
            background-color: #f39c12;
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
        ">
            Performance Overview
        </h1>
    </div>

    <h2 class="mt-4">School Performance</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Challenge No</th>
                <th>Challenge Name</th>
                <th>School Name</th>
                <th>Average Score</th>
                <th>Retrieved At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $schoolPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $retrievedAt = $schoolTimestamps->firstWhere('identifier', $school->schoolName)?->retrieved_at ?? 'Not Retrieved';
                ?>
                <tr>
                    <td><?php echo e($school->challengeNo); ?></td>
                    <td><?php echo e($school->challengeName); ?></td>
                    <td><?php echo e($school->schoolName); ?></td>
                    <td><?php echo e($school->schoolPerformance); ?></td>
                    <td><?php echo e($retrievedAt); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h2 class="mt-4">Participant Performance</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Challenge No</th>
                <th>Challenge Name</th>
                <th>User Name</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Average Score</th>
                <th>Retrieved At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $participantPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $retrievedAt = $participantTimestamps->firstWhere('identifier', $participant->userName)?->retrieved_at ?? 'Not Retrieved';
                ?>
                <tr>
                    <td><?php echo e($participant->challengeNo); ?></td>
                    <td><?php echo e($participant->challengeName); ?></td>
                    <td><?php echo e($participant->userName); ?></td>
                    <td><?php echo e($participant->firstName); ?></td>
                    <td><?php echo e($participant->lastName); ?></td>
                    <td><?php echo e($participant->performance); ?></td>
                    <td><?php echo e($retrievedAt); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Performance', 'title' => 'Performance Overview', 'navName' => 'Performance Overview', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/performance/index.blade.php ENDPATH**/ ?>