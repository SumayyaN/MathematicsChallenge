

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card">
        <div class="card-header text-center" style="
            background-color: #f39c12;
            color: white;
            padding: 20px;
            border-radius: 5px 5px 0 0;
        ">
            <h4 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                Participants with Incomplete Challenges
            </h4>
        </div>
        <div class="card-body">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <table class="table table-bordered table-striped">
                <thead style="
                    background-color: #f8f9fa;
                    color: #2c3e50;
                    font-weight: bold;
                ">
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Challenge Number</th>
                        <th>Attempt Number</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $incompleteChallenges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($challenge->userName); ?></td>
                            <td><?php echo e($challenge->email); ?></td>
                            <td><?php echo e($challenge->challengeNo); ?></td>
                            <td><?php echo e($challenge->attemptNo); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'table', 'title' => 'Incomplete Challenges', 'navName' => 'Incomplete Challenges', 'activeButton' => 'laravel'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aryam\Desktop\Coderants\mathChallenge\resources\views/incompletechallenges/index.blade.php ENDPATH**/ ?>