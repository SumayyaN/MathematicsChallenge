@extends('layouts.app', ['activePage' => 'School Rankings', 'title' => 'Ranking', 'navName' => 'Schools Ranking', 'activeButton' => 'laravel'])

@section('content')
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center" style="
                    background-color: #f39c12;
                    color: white;
                    padding: 20px;
                    border-radius: 5px 5px 0 0;
                ">
                    <h4 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                        School Rankings
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Challenge No</th>
                                <th>Challenge Name</th>
                                <th>School Registration No</th>
                                <th>School Name</th>
                                <th>Position</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($challengeRankings as $ranking)
                                <tr>
                                    <td>{{ $ranking->challengeNo }}</td>
                                    <td>{{ $ranking->challengeName }}</td>
                                    <td>{{ $ranking->regNo }}</td>
                                    <td>{{ $ranking->schoolName }}</td>
                                    <td>{{ $ranking->position }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
