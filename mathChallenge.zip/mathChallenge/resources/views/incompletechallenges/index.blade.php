@extends('layouts.app', ['activePage' => 'table', 'title' => 'Incomplete Challenges', 'navName' => 'Incomplete Challenges', 'activeButton' => 'laravel'])

@section('content')
<div class="container mt-5">
    <div class="card">
        <div class="card-header text-center" style="
            background-color: #f39c12;
            color: white;
            padding: 20px;
            border-radius: 5px 5px 0 0;
        ">
            <h4 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                Participants with Incomplete Challenges
            </h4>
        </div>
        <div class="card-body">
            @if ($message = Session::get('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    {{ $message }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif
            <table class="table table-bordered table-striped">
                <thead style="
                    background-color: #f8f9fa;
                    color: #2c3e50;
                    font-weight: bold;
                ">
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Challenge Number</th>
                        <th>Attempt Number</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($incompleteChallenges as $challenge)
                        <tr>
                            <td>{{ $challenge->userName }}</td>
                            <td>{{ $challenge->email }}</td>
                            <td>{{ $challenge->challengeNo }}</td>
                            <td>{{ $challenge->attemptNo }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
@endsection
