@extends('layouts.app', ['activePage' => 'Question Repetition Rate', 'title' => 'Question Repetition Rate', 'navName' => 'Question Repetition Rate', 'activeButton' => 'laravel'])

@section('content')
<div class="container mt-5">
    <div class="card">
        <div class="card-header text-center" style="
            background-color: #f39c12;
            color: white;
            padding: 20px;
            border-radius: 5px 5px 0 0;
        ">
            <h4 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                Question Repetition Report
            </h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>User Name</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Challenge No</th>
                        <th>Challenge Name</th>
                        <th>Question Repetition Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($data as $record)
                        <tr>
                            <td>{{ $record->userName }}</td>
                            <td>{{ $record->firstName }}</td>
                            <td>{{ $record->lastName }}</td>
                            <td>{{ $record->challengeNo }}</td>
                            <td>{{ $record->challengeName }}</td>
                            <td>{{ number_format($record->questionRepetitionPercentage, 1) }}%</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
