@extends('layouts.app', ['activePage' => 'Top Questions', 'title' => 'Top Questions', 'navName' => 'Top Questions', 'activeButton' => 'laravel'])

@section('content')
<div class="container mt-5">
    <div class="text-center mb-4">
        <h1 style="
            font-family: 'Arial, sans-serif';
            font-weight: bold;
            background-color: white;
            color: #f39c12;
            padding: 15px;
            border-radius: 5px;
            display: inline-block;
        ">Most Correctly Answered Questions</h1>
    </div>
    <table class="table table-striped" style="border-collapse: collapse;">
        <thead style="background-color: white; color: black;">
            <tr>
                <th style="border-right: 1px solid #ddd;">Challenge Number</th>
                <th style="border-right: 1px solid #ddd;">Question Number</th>
                <th style="border-right: 1px solid #ddd;">Question</th>
                <th>Correct Count</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($topQuestions as $question)
                <tr>
                    <td style="border-right: 1px solid #ddd;">{{ $question->challengeNo }}</td>
                    <td style="border-right: 1px solid #ddd;">{{ $question->questionNo }}</td>
                    <td style="border-right: 1px solid #ddd;">{{ $question->question }}</td>
                    <td>{{ $question->correct_count }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
