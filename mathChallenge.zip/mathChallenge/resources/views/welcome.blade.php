@extends('layouts/app', ['activePage' => 'welcome', 'title' => 'Math Challenge'])

@section('content')
    <div class="full-page section-image" data-color="" data-image="{{asset('light-bootstrap/img/bgr5.jpg')}}">
        <div class="content">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-8">
                        <h1 style="font-family: 'Arial, sans-serif'; color: #FFFDD0; -webkit-background-clip: text; -webkit-text-fill-color: font-size: 24px; font-weight: bold; padding: 10px; border-radius: 5px; border: 2px solid #00FFFF; text-align: center;">Welcome to the National Mathematics Challenge</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script>
        $(document).ready(function() {
            demo.checkFullPageBackgroundImage();

            setTimeout(function() {
                // after 1000 ms we add the class animated to the login/register card
                $('.card').removeClass('card-hidden');
            }, 700)
        });
    </script>
@endpush