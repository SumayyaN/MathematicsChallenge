@extends('layouts.app', ['activePage' => 'Performance', 'title' => 'Performance Overview', 'navName' => 'Performance Overview', 'activeButton' => 'laravel'])

@section('content')
<div class="container mt-5">
    <div class="text-center mb-4">
        <h1 style="
            font-family: 'Arial, sans-serif';
            color: white;
            background-color: #f39c12;
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
        ">
            Performance Overview
        </h1>
    </div>

    <h2 class="mt-4">School Performance</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Challenge No</th>
                <th>Challenge Name</th>
                <th>School Name</th>
                <th>Average Score</th>
                <th>Retrieved At</th>
            </tr>
        </thead>
        <tbody>
            @foreach($schoolPerformance as $school)
                @php
                    $retrievedAt = $schoolTimestamps->firstWhere('identifier', $school->schoolName)?->retrieved_at ?? 'Not Retrieved';
                @endphp
                <tr>
                    <td>{{ $school->challengeNo }}</td>
                    <td>{{ $school->challengeName }}</td>
                    <td>{{ $school->schoolName }}</td>
                    <td>{{ $school->schoolPerformance }}</td>
                    <td>{{ $retrievedAt }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <h2 class="mt-4">Participant Performance</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Challenge No</th>
                <th>Challenge Name</th>
                <th>User Name</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Average Score</th>
                <th>Retrieved At</th>
            </tr>
        </thead>
        <tbody>
            @foreach($participantPerformance as $participant)
                @php
                    $retrievedAt = $participantTimestamps->firstWhere('identifier', $participant->userName)?->retrieved_at ?? 'Not Retrieved';
                @endphp
                <tr>
                    <td>{{ $participant->challengeNo }}</td>
                    <td>{{ $participant->challengeName }}</td>
                    <td>{{ $participant->userName }}</td>
                    <td>{{ $participant->firstName }}</td>
                    <td>{{ $participant->lastName }}</td>
                    <td>{{ $participant->performance }}</td>
                    <td>{{ $retrievedAt }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
