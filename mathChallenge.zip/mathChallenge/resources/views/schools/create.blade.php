@extends('layouts.app', ['activePage' => 'table', 'title' => 'School Registration', 'navName' => 'School Registration', 'activeButton' => 'laravel'])

@section('content')
<div class="container mt-5">
    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card">
        <div class="card-header text-center" style="
            background-color: #f39c12;
            color: white;
            padding: 20px;
            border-radius: 5px 5px 0 0;
        ">
            <h2 style="font-family: 'Arial, sans-serif'; font-weight: bold; margin: 0;">
                Add New School
            </h2>
        </div>
        <div class="card-body">
            <form action="{{ route('schools.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label for="regNo">Registration Number:</label>
                    <input type="text" class="form-control" id="regNo" name="regNo" placeholder="Enter Registration Number" value="{{ old('regNo') }}" required>
                </div>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter School Name" value="{{ old('name') }}" required>
                </div>
                <div class="form-group">
                    <label for="district">District:</label>
                    <input type="text" class="form-control" id="district" name="district" placeholder="Enter District" value="{{ old('district') }}" required>
                </div>
                <div class="form-group">
                    <label for="representative_name">Representative Name:</label>
                    <input type="text" class="form-control" id="representative_name" name="school_representative_name" placeholder="Enter Representative Name" value="{{ old('school_representative_name') }}" required>
                </div>
                <div class="form-group">
                    <label for="representative_email">Representative Email:</label>
                    <input type="email" class="form-control" id="representative_email" name="school_representative_email" placeholder="Enter Representative Email" value="{{ old('school_representative_email') }}" required>
                </div>
                <div class="form-group">
                    <label for="representative_password">Representative Password:</label>
                    <input type="password" class="form-control" id="representative_password" name="representativePassword" placeholder="Enter Password" required>
                    <small class="form-text text-muted">
                        Password must be at least 8 characters long.
                    </small>
                </div>
                <button type="submit" class="btn btn-primary w-100">Submit</button>
            </form>
        </div>
    </div>
</div>
@endsection
