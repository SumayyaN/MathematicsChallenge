<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Use raw SQL to rename the column
        DB::statement('ALTER TABLE `schools` CHANGE `reg_no` `regNo` VARCHAR(255)');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Use raw SQL to rollback the column name change
        DB::statement('ALTER TABLE `schools` CHANGE `regNo` `reg_no` VARCHAR(255)');
    }
};
