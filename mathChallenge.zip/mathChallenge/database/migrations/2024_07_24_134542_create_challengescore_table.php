<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('challengescore', function (Blueprint $table) {
            $table->string('userName');
            $table->string('email');
            $table->integer('challengeNo')->unsigned();
            $table->integer('attemptNo')->unsigned();
            $table->integer('score');
            $table->timestamps = false; // Prevents automatic addition of timestamps
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('challengescore');
    }
};
