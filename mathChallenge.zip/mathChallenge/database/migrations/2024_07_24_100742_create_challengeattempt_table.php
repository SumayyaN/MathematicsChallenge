<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('challengeattempt', function (Blueprint $table) {
            $table->integer('attemptNo')->unsigned();
            $table->integer('challengeNo')->unsigned();
            $table->string('userName');
            $table->integer('questionNo')->unsigned();
            $table->string('comment');
            $table->timestamps = false;
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('challengeattempt');
    }
};
