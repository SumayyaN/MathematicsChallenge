<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
{
    Schema::create('challenges', function (Blueprint $table) {
        $table->string('challengeNo')->unique();
        $table->string('challengeName');
        $table->date('openDate');
        $table->date('closeDate');
        $table->integer('duration');
        $table->integer('numberOfQuestions');
    });
}

public function down()
{
    Schema::dropIfExists('challenges');
}
};
