<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('retrieval_timestamps', function (Blueprint $table) {
            // $table->id();
            $table->string('type'); // 'school' or 'participant'
            $table->string('identifier'); // unique identifier for the record (e.g., school name or user name)
            $table->timestamp('retrieved_at')->useCurrent();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('retrieval_timestamps');
    }
};
