<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use App\Models\Question;
use Maatwebsite\Excel\Concerns\WithHeadingRow;


class QuestionImport implements ToCollection, WithHeadingRow
{
    public function collection(Collection $rows)
    {
        foreach ($rows as $row)
        {
            Question::create([
                'challengeNo' => $row['challengeno'],
                'questionNo' => $row['questionno'],
                'question' => $row['question'],
            ]);
        }
    }
}