<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use App\Models\Answer;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class AnswerImport implements ToCollection, WithHeadingRow
{
    public function collection(Collection $rows)
    {
        foreach ($rows as $row)
        {
            Answer::create([
                'answerNo' => $row['answerno'],
                'answer' => $row['answer'],
                'mark' => $row['mark'],
            ]);
        }
    }
}