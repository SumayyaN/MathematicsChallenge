<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PerformanceController extends Controller
{
    public function index()
    {
        $currentDateTime = Carbon::now();

        // Query for school performance
        $schoolPerformance = DB::table('challengescore as cs')
            ->join('accepted as a', 'cs.userName', '=', 'a.userName')
            ->join('schools as s', 'a.regNo', '=', 's.regNo')
            ->join('challenges as ch', 'cs.challengeNo', '=', 'ch.challengeNo')
            ->select('ch.challengeNo', 'ch.challengeName', 's.name as schoolName', DB::raw('ROUND(AVG(cs.score), 1) as schoolPerformance'), DB::raw("'$currentDateTime' as retrievedAt"))
            ->groupBy('ch.challengeNo', 'ch.challengeName', 's.name')
            ->orderBy('ch.challengeNo', 'desc')
            ->orderBy('retrievedAt', 'desc')
            ->orderBy('s.name', 'asc')
            ->get();

        // Store retrieval timestamps for school performance only if not already set
        foreach ($schoolPerformance as $school) {
            $existingTimestamp = DB::table('retrieval_timestamps')
                ->where('type', 'school')
                ->where('identifier', $school->schoolName)
                ->first();

            if (!$existingTimestamp) {
                DB::table('retrieval_timestamps')->insert([
                    'type' => 'school',
                    'identifier' => $school->schoolName,
                    'retrieved_at' => $currentDateTime
                ]);
            }
        }


        // Query for participant performance
        $participantPerformance = DB::table('challengescore as cs')
            ->join('accepted as a', 'cs.userName', '=', 'a.userName')
            ->join('challenges as ch', 'cs.challengeNo', '=', 'ch.challengeNo')
            ->select('ch.challengeNo', 'ch.challengeName', 'a.userName', 'a.firstName', 'a.lastName', DB::raw('ROUND(AVG(cs.score), 1) as performance'), DB::raw("'$currentDateTime' as retrievedAt"))
            ->groupBy('ch.challengeNo', 'ch.challengeName', 'a.userName', 'a.firstName', 'a.lastName')
            ->orderBy('ch.challengeNo', 'desc')
            ->orderBy('retrievedAt', 'desc')
            ->orderBy('a.userName', 'asc')
            ->get();

        // Store retrieval timestamps for participant performance only if not already set
        foreach ($participantPerformance as $participant) {
            $existingTimestamp = DB::table('retrieval_timestamps')
                ->where('type', 'participant')
                ->where('identifier', $participant->userName)
                ->first();

            if (!$existingTimestamp) {
                DB::table('retrieval_timestamps')->insert([
                    'type' => 'participant',
                    'identifier' => $participant->userName,
                    'retrieved_at' => $currentDateTime
                ]);
            }
        }

                // Fetch retrieval timestamps
        $schoolTimestamps = DB::table('retrieval_timestamps')->where('type', 'school')->orderBy('retrieved_at', 'desc')->get();
        $participantTimestamps = DB::table('retrieval_timestamps')->where('type', 'participant')->orderBy('retrieved_at', 'desc')->get();

        // Pass data to the view
        return view('performance.index', [
            'schoolPerformance' => $schoolPerformance,
            'participantPerformance' => $participantPerformance,
            'schoolTimestamps' => $schoolTimestamps,
            'participantTimestamps' => $participantTimestamps
        ]);
    }
}
