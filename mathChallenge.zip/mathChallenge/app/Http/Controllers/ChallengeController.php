<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Challenge;

class ChallengeController extends Controller
{
    public function index()
    {
        return view('challenges.index');
    }

    public function store(Request $request)
    {
        $request->validate([
            'challengeNo' => 'required|unique:challenges',
            'challengeName' => 'required',
            'openDate' => 'required|date',
            'closeDate' => 'required|date',
            'duration' => 'required|integer',
            'numberOfQuestions' => 'required|integer',
        ]);

        Challenge::create($request->all());

        return redirect()->back()->with('success', 'Challenge details uploaded successfully.');
    }
}

