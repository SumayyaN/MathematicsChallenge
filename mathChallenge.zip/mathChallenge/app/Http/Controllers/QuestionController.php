<?php

namespace App\Http\Controllers;

use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;
use App\Imports\QuestionImport;
use App\Imports\AnswerImport;

class QuestionController extends Controller
{
    public function index()
    {
        return view('question.index');
    }

    public function importQuestions(Request $request)
    {
        $request->validate([
            'questionFile' => ['required', 'file']
        ]);

        try {
            Excel::import(new QuestionImport, $request->file('questionFile'));
            return response()->json(['status' => 'Questions imported successfully']);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function importAnswers(Request $request)
    {
        $request->validate([
            'answerFile' => ['required', 'file']
        ]);

        try {
            Excel::import(new AnswerImport, $request->file('answerFile'));
            return response()->json(['status' => 'Answers imported successfully']);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
