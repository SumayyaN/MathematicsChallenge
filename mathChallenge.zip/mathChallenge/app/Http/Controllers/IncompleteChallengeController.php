<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\IncompleteChallenge;

class IncompleteChallengeController extends Controller
{
    public function index()
    {
        $incompleteChallenges = IncompleteChallenge::all();
        return view('incompletechallenges.index', compact('incompleteChallenges'));
    }
}
