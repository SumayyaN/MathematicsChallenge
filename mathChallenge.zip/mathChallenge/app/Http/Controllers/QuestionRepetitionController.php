<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QuestionRepetitionController extends Controller
{
    public function index()
    {
        $data = DB::table(DB::raw('(
            SELECT 
                a.userName, 
                a.firstName, 
                a.lastName,
                ch.challengeNo,
                ch.challengeName,
                IFNULL(SUM(ca.totalRepetitions), 0) / COUNT(ca.questionNo) * 100 AS questionRepetitionPercentage
            FROM 
                challenges ch
            JOIN 
                (SELECT 
                    userName,
                    challengeNo,
                    questionNo,
                    (COUNT(*) - 1) AS totalRepetitions
                 FROM 
                    challengeattempt
                 GROUP BY 
                    userName, 
                    challengeNo, 
                    questionNo
                ) ca ON ch.challengeNo = ca.challengeNo
            JOIN 
                accepted a ON ca.userName = a.userName
            GROUP BY 
                a.userName, 
                a.firstName, 
                a.lastName, 
                ch.challengeNo, 
                ch.challengeName
        ) AS derived'))
        ->get();

        return view('question-repetition.index', compact('data'));
    }
}
