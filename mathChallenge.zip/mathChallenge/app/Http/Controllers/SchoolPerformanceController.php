<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SchoolPerformanceController extends Controller
{
    public function index()
    {
        // Query for top 20 worst-performing schools per challenge
        $worstPerformingSchools = DB::select(DB::raw('
            WITH SchoolPerformance AS (
                SELECT 
                    c.challengeNo, 
                    c.challengeName, 
                    s.regNo, 
                    s.name AS schoolName, 
                    AVG(cs.score) AS averageScore
                FROM 
                    challengescore cs
                JOIN 
                    accepted a ON cs.userName = a.userName
                JOIN 
                    schools s ON a.regNo = s.regNo
                JOIN 
                    challenges c ON cs.challengeNo = c.challengeNo
                GROUP BY 
                    c.challengeNo, 
                    c.challengeName, 
                    s.regNo, 
                    s.name
            ),
            RankedPerformance AS (
                SELECT 
                    challengeNo, 
                    challengeName, 
                    regNo, 
                    schoolName, 
                    averageScore,
                    ROW_NUMBER() OVER (PARTITION BY challengeNo ORDER BY averageScore ASC) AS rank
                FROM 
                    SchoolPerformance
            )
            SELECT 
                challengeNo, 
                challengeName, 
                regNo, 
                schoolName, 
                averageScore AS schoolPerformance
            FROM 
                RankedPerformance
            WHERE 
                rank <= 20
            ORDER BY 
                challengeNo, rank
        '));

        // Query for top 20 best-performing schools across all challenges
        $bestPerformingSchools = DB::select(DB::raw('
            WITH ChallengeAverage AS (
                SELECT 
                    s.regNo, 
                    s.name AS schoolName, 
                    c.challengeNo, 
                    AVG(cs.score) AS averageScore
                FROM 
                    challengescore cs
                JOIN 
                    accepted a ON cs.userName = a.userName
                JOIN 
                    schools s ON a.regNo = s.regNo
                JOIN 
                    challenges c ON cs.challengeNo = c.challengeNo
                GROUP BY 
                    s.regNo, 
                    s.name, 
                    c.challengeNo
            ),
            SchoolOverallPerformance AS (
                SELECT 
                    regNo, 
                    schoolName, 
                    AVG(averageScore) AS overallPerformance
                FROM 
                    ChallengeAverage
                GROUP BY 
                    regNo, 
                    schoolName
            )
            SELECT 
                regNo, 
                schoolName, 
                overallPerformance AS schoolPerformance
            FROM 
                SchoolOverallPerformance
            ORDER BY 
                overallPerformance DESC
            LIMIT 20
        '));

        return view('combined-performance.index', compact('worstPerformingSchools', 'bestPerformingSchools'));
    }
}
