<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\School;

class SchoolController extends Controller
{
    public function create()
    {
        return view('schools.create');
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'regNo' => 'required|unique:schools|max:255',
            'name' => 'required|max:255',
            'district' => 'required|max:255',
            'school_representative_name' => 'required|max:255',
            'school_representative_email' => 'required|unique:schools|email|max:255',
            'representativePassword' => 'required|min:8',
        ]);
        
        $school = School::create($validatedData);

        return redirect()->route('schools.create')->with('success', 'School added successfully.');
    }
}
