<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ChallengeRankingController extends Controller
{
    public function index()
    {
        $challengeRankings = DB::table('challengescore as cs')
            ->join('accepted as a', 'cs.userName', '=', 'a.userName')
            ->join('schools as s', 'a.regNo', '=', 's.regNo')
            ->join('challenges as c', 'cs.challengeNo', '=', 'c.challengeNo')
            ->select(
                'c.challengeNo',
                'c.challengeName',
                's.regNo',
                's.name as schoolName',
                DB::raw('RANK() OVER (PARTITION BY c.challengeNo ORDER BY AVG(cs.score) DESC) as position')
            )
            ->groupBy('c.challengeNo', 'c.challengeName', 's.regNo', 's.name')
            ->orderBy('c.challengeNo')
            ->orderBy('position')
            ->get();

        return view('challenge.rankings', ['challengeRankings' => $challengeRankings]);
    }
}
