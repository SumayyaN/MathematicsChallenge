<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TopQuestionController extends Controller
{
    public function topQuestions()
    {
    // Run the query to fetch the top 5 questions with the highest frequency of "correct" comments
    $topQuestions = DB::table('challengeattempt as ca')
        ->join('question as q', 'ca.questionNo', '=', 'q.questionNo')
        ->select('q.challengeNo', 'q.questionNo', 'q.question', DB::raw('COUNT(ca.comment) as correct_count'))
        ->where('ca.comment', 'correct')
        ->groupBy('q.challengeNo', 'q.questionNo', 'q.question')
        ->orderBy('correct_count', 'desc')
        ->limit(20)
        ->get();

    // Pass the data to the view
    return view('TopQuestions\top-questions', ['topQuestions' => $topQuestions]);
    }
}
