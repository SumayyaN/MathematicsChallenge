<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TopQuestionController;
use App\Http\Controllers\ChallengeRankingController;
use App\Http\Controllers\PerformanceController;
use App\Http\Controllers\QuestionRepetitionController;
use App\Http\Controllers\SchoolPerformanceController;
use App\Http\Controllers\IncompleteChallengeController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('answer/import',[App\Http\Controllers\AnswerController::class,'index']);


Route::get('/', function () {
    return view('welcome');
});

Route::get('/challenge/rankings', [ChallengeRankingController::class, 'index'])->name('rankings.index');

Route::get('TopQuestions/top-questions', [TopQuestionController::class, 'topQuestions'])->name('top-questions.topQuestions');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Auth::routes();

Route::get('/home', 'App\Http\Controllers\HomeController@index')->name('dashboard');

Route::group(['middleware' => 'auth'], function () {
	Route::resource('user', 'App\Http\Controllers\UserController', ['except' => ['show']]);
	Route::get('profile', ['as' => 'profile.edit', 'uses' => 'App\Http\Controllers\ProfileController@edit']);
	Route::patch('profile', ['as' => 'profile.update', 'uses' => 'App\Http\Controllers\ProfileController@update']);
	Route::patch('profile/password', ['as' => 'profile.password', 'uses' => 'App\Http\Controllers\ProfileController@password']);
});

Route::group(['middleware' => 'auth'], function () {
	Route::get('{page}', ['as' => 'page.index', 'uses' => 'App\Http\Controllers\PageController@index']);
});

use App\Http\Controllers\SchoolController;

Route::get('/schools/create', [SchoolController::class, 'create'])->name('schools.create');
Route::post('/schools', [SchoolController::class, 'store'])->name('schools.store');

use App\Http\Controllers\ChallengeController;

Route::get('/challenges/index', [ChallengeController::class, 'index'])->name('challenges.index');
Route::post('/challenges', [ChallengeController::class, 'store'])->name('challenges.store');

Route::get('question/import',[App\Http\Controllers\QuestionController::class,'index'])->name('question.index');
Route::post('question/import',[App\Http\Controllers\QuestionController::class,'importQuestions']);
Route::post('answer/import',[App\Http\Controllers\QuestionController::class,'importAnswers']);

Route::get('/performance/index', [PerformanceController::class, 'index'])->name('performance');

Route::get('/question-repetition/index', [QuestionRepetitionController::class, 'index'])->name('question.repetition');

Route::get('/combined-performance/index', [SchoolPerformanceController::class, 'index'])->name('combined.performance');

Route::get('/incompletechallenges/index', [IncompleteChallengeController::class, 'index'])->name('incompletechallenges');





